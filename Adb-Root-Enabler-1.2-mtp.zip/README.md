# Adb-Root-Enabler

### Description
Enable unauthenticated adb daemon, usefull for broken screen !


#### Copyright (c) lexavey @ github, 2023-

